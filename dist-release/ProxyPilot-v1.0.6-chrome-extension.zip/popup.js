let currentDomain = '';
let currentUrl = '';
let currentTabId = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Query proxy control status
  chrome.runtime.sendMessage({ type: 'GET_PROXY_CONTROL_STATUS' }, (statusRes) => {
    if (statusRes && statusRes.warningMessage) {
      const conflictEl = document.getElementById('conflict-alert');
      if (conflictEl) {
        conflictEl.style.display = 'block';
        conflictEl.innerHTML = '<strong>⚠️ 代理权冲突：</strong>' + statusRes.warningMessage;
      }
    }
  });

  // Query active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0] && tabs[0].url) {
      currentTabId = tabs[0].id;
      try {
        const u = new URL(tabs[0].url);
        currentDomain = u.hostname;
        currentUrl = tabs[0].url;
        document.getElementById('domain-display').textContent = currentDomain || tabs[0].url;
      } catch {
        document.getElementById('domain-display').textContent = tabs[0].url;
      }
    } else {
      document.getElementById('domain-display').textContent = 'chrome://';
    }
  });

  // Load profiles
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (res) => {
    if (!res) return;
    const container = document.getElementById('profile-container');
    container.innerHTML = '';

    const curActive = res.profiles.find(p => p.id === res.activeProfileId);
    const statusBadge = document.getElementById('status-badge');
    if (statusBadge && curActive) {
      statusBadge.textContent = curActive.name.substring(0, 14);
    }

    res.profiles.forEach(p => {
      const isAct = p.id === res.activeProfileId;
      const div = document.createElement('div');
      div.className = 'profile-item' + (isAct ? ' active' : '');
      div.innerHTML = `
        <span class="color-dot" style="background: ${p.color || '#3b82f6'}"></span>
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;">${p.name}</span>
        ${isAct ? '<span style="color:#10b981;font-weight:bold;font-size:11px;">● 已接管</span>' : '<span style="font-size:11px;color:#94a3b8;">设为代理</span>'}
      `;
      div.onclick = () => {
        const takeoverMsg = document.getElementById('takeover-msg');
        if (takeoverMsg) {
          takeoverMsg.style.display = 'block';
          takeoverMsg.textContent = '⚡ 正在将浏览器代理切换至: ' + p.name + '...';
        }
        chrome.runtime.sendMessage({ type: 'SWITCH_PROFILE', profileId: p.id }, () => {
          setTimeout(() => {
            window.location.reload();
          }, 200);
        });
      };
      container.appendChild(div);
    });

    const overrideBtn = document.getElementById('btn-toggle-override');
    if (overrideBtn) {
      overrideBtn.onclick = () => {
        const targetId = res.activeProfileId === 'direct' ? 'proxy_clash' : 'direct';
        chrome.runtime.sendMessage({
          type: 'SWITCH_PROFILE',
          profileId: targetId
        }, () => {
          alert('已临时接管分流模式至: ' + targetId);
          window.location.reload();
        });
      };
    }
  });

  document.getElementById('btn-add-rule').onclick = () => {
    if (!currentDomain) return;
    const wildcard = '*.' + (currentDomain.replace(/^www\./, ''));
    chrome.runtime.sendMessage({
      type: 'ADD_RULE',
      pattern: wildcard,
      targetProfileId: 'proxy_clash'
    }, (res) => {
      alert('已成功添加分流规则: ' + wildcard + ' -> 7897 代理端口');
    });
  };

  document.getElementById('open-inspector').onclick = (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('options.html#tab=inspector') });
  };

  document.getElementById('open-options').onclick = (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  };
});
