// ProxyPilot - Background Service Worker (Manifest V3)
// Strictly ASCII-compliant proxy manager for Chrome, Edge, and Kiwi Browser.

const DEFAULT_PROFILES = [
  {
    "id": "direct",
    "name": "直接连接 (Direct)",
    "profileType": "DirectProfile",
    "color": "#64748b"
  },
  {
    "id": "system",
    "name": "系统代理 (System)",
    "profileType": "SystemProfile",
    "color": "#0284c7"
  },
  {
    "id": "proxy_clash",
    "name": "Proxy (SOCKS5 7897)",
    "profileType": "FixedProfile",
    "color": "#10b981",
    "useSingleProxy": true,
    "fallbackProxy": {
      "scheme": "socks5",
      "host": "127.0.0.1",
      "port": 7897
    },
    "bypassList": [
      {
        "id": "b1",
        "pattern": "127.0.0.1",
        "enabled": true
      },
      {
        "id": "b2",
        "pattern": "[::1]",
        "enabled": true
      },
      {
        "id": "b3",
        "pattern": "localhost",
        "enabled": true
      },
      {
        "id": "b4",
        "pattern": "192.168.*",
        "enabled": true
      },
      {
        "id": "b5",
        "pattern": "10.*",
        "enabled": true
      },
      {
        "id": "b6",
        "pattern": "<local>",
        "enabled": true
      }
    ]
  },
  {
    "id": "proxy_http",
    "name": "HTTP 代理 (7897)",
    "profileType": "FixedProfile",
    "color": "#8b5cf6",
    "useSingleProxy": true,
    "fallbackProxy": {
      "scheme": "http",
      "host": "127.0.0.1",
      "port": 7897
    },
    "bypassList": [
      {
        "id": "b1",
        "pattern": "127.0.0.1",
        "enabled": true
      },
      {
        "id": "b2",
        "pattern": "localhost",
        "enabled": true
      },
      {
        "id": "b3",
        "pattern": "<local>",
        "enabled": true
      }
    ]
  },
  {
    "id": "auto_switch",
    "name": "自动切换 (Auto Switch)",
    "profileType": "SwitchProfile",
    "color": "#f59e0b",
    "defaultProfileId": "direct",
    "rules": [
      {
        "id": "r1",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.google.com",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "Google 国际服务"
      },
      {
        "id": "r2",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.github.com",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "GitHub 开发加速"
      },
      {
        "id": "r3",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.youtube.com",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "YouTube 媒体"
      },
      {
        "id": "r4",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.wikipedia.org",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "维基百科"
      },
      {
        "id": "r5",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.internal.corp",
        "profileId": "direct",
        "enabled": true,
        "note": "公司内部服务直连"
      },
      {
        "id": "r6",
        "conditionType": "UrlRegexCondition",
        "pattern": "^https?://192\\.168\\.\\d+\\.\\d+",
        "profileId": "direct",
        "enabled": true,
        "note": "局域网网段直接访问"
      }
    ],
    "ruleListConfig": {
      "enabled": true,
      "url": "https://raw.githubusercontent.com/gfwlist/gfwlist/master/gfwlist.txt",
      "format": "AutoProxy",
      "profileId": "proxy_clash",
      "defaultProfileId": "direct",
      "rulesText": "! Sample AutoProxy / GFWList segment\n||twitter.com\n||x.com\n||facebook.com\n||instagram.com\n||reddit.com\n||medium.com\n||notion.so\n||openai.com\n@@||baidu.com\n@@||taobao.com\n@@||bilibili.com",
      "lastUpdated": "2026-10-31 08:00:00"
    }
  },
  {
    "id": "pac_custom",
    "name": "PAC 智能脚本 (PAC Script)",
    "profileType": "PacProfile",
    "color": "#ec4899",
    "pacUrl": "http://127.0.0.1:7897/proxy.pac",
    "pacScript": "function FindProxyForURL(url, host) {\n  // Local direct connection\n  if (isPlainHostName(host) ||\n      shExpMatch(host, \"*.local\") ||\n      isInNet(dnsResolve(host), \"10.0.0.0\", \"255.0.0.0\") ||\n      isInNet(dnsResolve(host), \"192.168.0.0\", \"255.255.0.0\")) {\n    return \"DIRECT\";\n  }\n\n  // Development domains\n  if (shExpMatch(host, \"*.dev.internal\")) {\n    return \"PROXY 127.0.0.1:7897; DIRECT\";\n  }\n\n  // Smart proxy routing\n  if (shExpMatch(host, \"*.google.com\") || shExpMatch(host, \"*.github.com\")) {\n    return \"SOCKS5 127.0.0.1:7897; SOCKS 127.0.0.1:7897; DIRECT\";\n  }\n\n  return \"DIRECT\";\n}"
  }
];
let currentActiveProfileId = "auto_switch";

// Enforce strictly pure ASCII characters (charCode <= 127) for Chromium PAC specification
function toPureAscii(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[^\x00-\x7F]/g, '');
}

// Format PAC proxy return instruction (e.g. 'SOCKS5 127.0.0.1:7897; DIRECT')
function formatPacStatement(prof) {
  if (!prof) return 'DIRECT';
  if (prof.profileType === 'DirectProfile') return 'DIRECT';
  if (prof.profileType === 'SystemProfile') return 'SYSTEM';
  if (prof.profileType === 'FixedProfile' && prof.fallbackProxy) {
    const p = prof.fallbackProxy;
    const host = toPureAscii(p.host || '127.0.0.1');
    const port = p.port || 7897;
    const scheme = (p.scheme || 'socks5').toLowerCase();
    if (scheme === 'socks5') {
      return 'SOCKS5 ' + host + ':' + port + '; SOCKS ' + host + ':' + port + '; DIRECT';
    }
    if (scheme === 'socks4') {
      return 'SOCKS ' + host + ':' + port + '; DIRECT';
    }
    if (scheme === 'https') {
      return 'HTTPS ' + host + ':' + port + '; DIRECT';
    }
    return 'PROXY ' + host + ':' + port + '; DIRECT';
  }
  return 'DIRECT';
}

// Generate RFC-compliant, 100% pure ASCII FindProxyForURL script
function buildPacScriptForProfile(target, allProfiles) {
  if (target.profileType === 'PacProfile' && target.pacScript) {
    return toPureAscii(target.pacScript);
  }

  if (target.profileType === 'DirectProfile') {
    return '// ProxyPilot PAC Script - Direct\nfunction FindProxyForURL(url, host) {\n  return "DIRECT";\n}';
  }

  if (target.profileType === 'SystemProfile') {
    return '// ProxyPilot PAC Script - System\nfunction FindProxyForURL(url, host) {\n  return "SYSTEM";\n}';
  }

  if (target.profileType === 'FixedProfile') {
    const ret = formatPacStatement(target);
    const bypassLines = (target.bypassList || [])
      .filter(b => b.enabled)
      .map(b => {
        const pat = toPureAscii(b.pattern);
        if (pat === '<local>') {
          return '  if (isPlainHostName(host) || host === "127.0.0.1" || host === "localhost") return "DIRECT";';
        }
        if (pat.includes('*') || pat.includes('?')) {
          return '  if (shExpMatch(host, "' + pat + '") || shExpMatch(url, "' + pat + '")) return "DIRECT";';
        }
        return '  if (host === "' + pat + '") return "DIRECT";';
      })
      .join('\n');

    return '// ProxyPilot PAC Script - Fixed Proxy\n' +
      'function FindProxyForURL(url, host) {\n' +
      (bypassLines ? bypassLines + '\n' : '') +
      '  return "' + ret + '";\n' +
      '}';
  }

  if (target.profileType === 'SwitchProfile') {
    const sw = target;
    const defProf = allProfiles.find(p => p.id === sw.defaultProfileId) || allProfiles.find(p => p.id === 'direct');
    const defaultRet = formatPacStatement(defProf);

    const ruleLines = [];
    const rules = sw.rules || [];
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i];
      if (!r.enabled) continue;
      const targetProf = allProfiles.find(p => p.id === r.profileId);
      const targetRet = formatPacStatement(targetProf);
      const cleanPat = toPureAscii(r.pattern);

      if (r.conditionType === 'HostWildcardCondition') {
        ruleLines.push('  // Rule ' + (i + 1) + '\n  if (shExpMatch(host, "' + cleanPat + '")) return "' + targetRet + '";');
      } else if (r.conditionType === 'UrlWildcardCondition') {
        ruleLines.push('  // Rule ' + (i + 1) + '\n  if (shExpMatch(url, "' + cleanPat + '")) return "' + targetRet + '";');
      } else if (r.conditionType === 'HostRegexCondition') {
        ruleLines.push('  // Rule ' + (i + 1) + '\n  if (/' + cleanPat + '/i.test(host)) return "' + targetRet + '";');
      } else if (r.conditionType === 'UrlRegexCondition') {
        ruleLines.push('  // Rule ' + (i + 1) + '\n  if (/' + cleanPat + '/i.test(url)) return "' + targetRet + '";');
      } else if (r.conditionType === 'KeywordCondition') {
        ruleLines.push('  // Rule ' + (i + 1) + '\n  if (url.indexOf("' + cleanPat + '") !== -1 || host.indexOf("' + cleanPat + '") !== -1) return "' + targetRet + '";');
      } else if (r.conditionType === 'IpCidrCondition') {
        var parts = cleanPat.split('/');
        var cidrIp = parts[0] || '';
        var cidrPrefix = parseInt(parts[1] || '32', 10);
        var p = Math.max(0, Math.min(32, cidrPrefix));
        var maskArr = [];
        var rem = p;
        for (var mi = 0; mi < 4; mi++) {
          var n = Math.min(rem, 8);
          maskArr.push(256 - Math.pow(2, 8 - n));
          rem -= n;
        }
        var cidrMask = maskArr.join('.');
        ruleLines.push('  // Rule ' + (i + 1) + ' CIDR\n  if (isInNet(dnsResolve(host), "' + cidrIp + '", "' + cidrMask + '")) return "' + targetRet + '";');
      } else if (r.conditionType === 'PortCondition') {
        var portStr = cleanPat.replace(/^:/, '').trim();
        ruleLines.push('  // Rule ' + (i + 1) + ' Port\n  var pMatch = (url.match(/:([0-9]+)/) || [])[1];\n  if (pMatch === "' + portStr + '") return "' + targetRet + '";');
      } else if (r.conditionType === 'SchemeCondition') {
        var schemeStr = cleanPat.replace(/:$/, '').trim().toLowerCase();
        ruleLines.push('  // Rule ' + (i + 1) + ' Scheme\n  if (url.indexOf("' + schemeStr + ':") === 0) return "' + targetRet + '";');
      } else if (r.conditionType === 'ResourceTypeCondition') {
        var rt = cleanPat.toLowerCase();
        if (rt.indexOf('image') !== -1) {
          ruleLines.push('  // Rule ' + (i + 1) + ' Resource Type (Image)\n  if (/\.(png|jpe?g|gif|webp|svg|ico)(\?.*)?$/i.test(url)) return "' + targetRet + '";');
        } else if (rt.indexOf('media') !== -1 || rt.indexOf('video') !== -1) {
          ruleLines.push('  // Rule ' + (i + 1) + ' Resource Type (Media)\n  if (/\.(mp4|webm|m3u8|ts|mp3|ogg|flv|wav)(\?.*)?$/i.test(url)) return "' + targetRet + '";');
        } else if (rt.indexOf('script') !== -1 || rt.indexOf('js') !== -1) {
          ruleLines.push('  // Rule ' + (i + 1) + ' Resource Type (Script)\n  if (/\.js(\?.*)?$/i.test(url)) return "' + targetRet + '";');
        } else if (rt.indexOf('style') !== -1 || rt.indexOf('css') !== -1) {
          ruleLines.push('  // Rule ' + (i + 1) + ' Resource Type (CSS)\n  if (/\.css(\?.*)?$/i.test(url)) return "' + targetRet + '";');
        } else if (rt.indexOf('ws') !== -1 || rt.indexOf('websocket') !== -1) {
          ruleLines.push('  // Rule ' + (i + 1) + ' Resource Type (WebSocket)\n  if (/^wss?:/i.test(url)) return "' + targetRet + '";');
        } else {
          ruleLines.push('  // Rule ' + (i + 1) + ' Resource Type\n  if (shExpMatch(url, "' + cleanPat + '")) return "' + targetRet + '";');
        }
      }
    }

    let ruleListBlock = '';
    if (sw.ruleListConfig && sw.ruleListConfig.enabled && sw.ruleListConfig.rulesText) {
      const listTarget = allProfiles.find(p => p.id === sw.ruleListConfig.profileId);
      const listRet = formatPacStatement(listTarget);

      const rLines = sw.ruleListConfig.rulesText.split(/?
/);
      const proxyMap: Record<string, number> = {};
      const whiteMap: Record<string, number> = {};
      for (let li = 0; li < rLines.length; li++) {
        const l = rLines[li].trim();
        if (!l || l.charAt(0) === '!' || l.charAt(0) === '[') continue;
        if (l.indexOf('@@') === 0) {
          const clean = toPureAscii(l.replace(/^@@(||)?/, '').replace(/^https?:///, '').split('/')[0].trim().toLowerCase());
          if (clean && clean.indexOf('*') === -1 && clean.indexOf('^') === -1) whiteMap[clean] = 1;
        } else if (l.indexOf('||') === 0) {
          const clean = toPureAscii(l.substring(2).replace(/^/+/, '').split('/')[0].trim().toLowerCase());
          if (clean && clean.indexOf('*') === -1 && clean.indexOf('^') === -1) proxyMap[clean] = 1;
        } else if (l.charAt(0) !== '|' && l.charAt(0) !== '/' && l.indexOf('.') !== -1 && l.indexOf(' ') === -1 && l.indexOf('*') === -1) {
          const clean = toPureAscii(l.split('/')[0].trim().toLowerCase());
          if (clean) proxyMap[clean] = 1;
        }
      }

      ruleListBlock = '\n  // GFWList / Online Rule List Segment (Fast Hash Map)\n' +
        '  var gfwWhite = ' + JSON.stringify(whiteMap) + ';\n' +
        '  var gfwProxy = ' + JSON.stringify(proxyMap) + ';\n' +
        '  if (matchDomainMap(host, gfwWhite)) return "DIRECT";\n' +
        '  if (matchDomainMap(host, gfwProxy)) return "' + listRet + '";\n';
    }

    return '// ProxyPilot PAC Script - Auto Switch\n' +
      'function FindProxyForURL(url, host) {\n' +
      '  // Mandatory Security Direct Whitelist (Never Proxy)\n' +
      '  if (isPlainHostName(host) || host === "127.0.0.1" || host === "localhost" || host === "::1" || ' +
      'shExpMatch(host, "*.gov.cn") || shExpMatch(host, "*.edu.cn") || ' +
      'shExpMatch(host, "*.icbc.com.cn") || shExpMatch(host, "*.ccb.com") || shExpMatch(host, "*.boc.cn") || ' +
      'shExpMatch(host, "*.abchina.com") || shExpMatch(host, "*.cmbchina.com") || shExpMatch(host, "*.alipay.com") || ' +
      'isInNet(dnsResolve(host), "10.0.0.0", "255.0.0.0") || isInNet(dnsResolve(host), "172.16.0.0", "255.240.0.0") || isInNet(dnsResolve(host), "192.168.0.0", "255.255.0.0")) {\n' +
      '    return "DIRECT";\n' +
      '  }\n\n' +
      ruleLines.join('\n\n') +
      ruleListBlock +
      '\n  // Default fallback\n' +
      '  return "' + defaultRet + '";\n' +
      '}\n\n' +
      'function matchDomainMap(h, map) {\n' +
      '  if (!h || !map) return false;\n' +
      '  h = h.toLowerCase();\n' +
      '  if (map[h]) return true;\n' +
      '  var dot = h.indexOf(".");\n' +
      '  while (dot !== -1) {\n' +
      '    var parent = h.substring(dot + 1);\n' +
      '    if (map[parent]) return true;\n' +
      '    dot = h.indexOf(".", dot + 1);\n' +
      '  }\n' +
      '  return false;\n' +
      '}';
  }

  return '// ProxyPilot Fallback\nfunction FindProxyForURL(url, host) { return "DIRECT"; }';
}

// Update Extension Icon Badge & Tooltip
function updateActionBadge(target) {
  if (!chrome.action) return;
  let badgeText = '7897';
  let badgeColor = '#10b981';
  if (target.profileType === 'DirectProfile') {
    badgeText = 'DIR';
    badgeColor = '#64748b';
  } else if (target.profileType === 'SystemProfile') {
    badgeText = 'SYS';
    badgeColor = '#0284c7';
  } else if (target.profileType === 'SwitchProfile') {
    badgeText = 'AUTO';
    badgeColor = '#f59e0b';
  } else if (target.profileType === 'PacProfile') {
    badgeText = 'PAC';
    badgeColor = '#8b5cf6';
  } else if (target.profileType === 'FixedProfile' && target.fallbackProxy) {
    badgeText = String(target.fallbackProxy.port || '7897');
    badgeColor = '#10b981';
  }

  try {
    if (chrome.action.setBadgeText) chrome.action.setBadgeText({ text: badgeText });
    if (chrome.action.setBadgeBackgroundColor) chrome.action.setBadgeBackgroundColor({ color: badgeColor });
    if (chrome.action.setTitle) {
      chrome.action.setTitle({
        title: 'ProxyPilot (当前已接管浏览器代理: ' + target.name + ' [' + badgeText + '])'
      });
    }
  } catch (e) {}
}

let lastControlStatus = {
  levelOfControl: 'controllable_by_this_extension',
  activeProfileId: currentActiveProfileId,
  warningMessage: ''
};

function verifyProxyControl(label) {
  if (chrome.proxy && chrome.proxy.settings && chrome.proxy.settings.get) {
    chrome.proxy.settings.get({ incognito: false }, (details) => {
      const loc = details ? details.levelOfControl : 'unknown';
      let warn = '';
      if (loc === 'controlled_by_other_extensions') {
        warn = '检测到浏览器中安装了其他代理扩展（如 SwitchyOmega、Clash Verge 等），正在占用代理控制权。请在 chrome://extensions 临时禁用其他代理插件。';
        console.warn('[ProxyPilot] Warning:', warn);
      } else if (loc === 'not_controllable') {
        warn = '浏览器代理被系统或企业策略锁定，无法由扩展程序修改。';
        console.warn('[ProxyPilot] Warning:', warn);
      } else {
        console.log('[ProxyPilot] Verified: ProxyPilot is in full control of browser proxy settings (' + loc + ')');
      }
      lastControlStatus = {
        levelOfControl: loc,
        activeProfileId: currentActiveProfileId,
        warningMessage: warn
      };
    });
  }
}

// Safely apply proxy settings and inspect chrome.runtime.lastError
function setChromeProxy(config, label) {
  if (!chrome.proxy || !chrome.proxy.settings) {
    console.warn('[ProxyPilot] chrome.proxy.settings API not available');
    return;
  }
  chrome.proxy.settings.set({
    value: config,
    scope: 'regular'
  }, () => {
    if (chrome.runtime.lastError) {
      console.error('[ProxyPilot] Error applying proxy (' + label + '):', chrome.runtime.lastError.message);
    } else {
      console.log('[ProxyPilot] Successfully applied proxy settings to browser:', label);
      verifyProxyControl(label);
    }
  });
}

// Apply proxy settings using Chrome Proxy API
async function applyProxySettings(profileId) {
  currentActiveProfileId = profileId;
  await chrome.storage.local.set({ activeProfileId: profileId });

  const stored = await chrome.storage.local.get(['profiles']);
  const allProfiles = stored.profiles || DEFAULT_PROFILES;
  const target = allProfiles.find(p => p.id === profileId) || allProfiles[0];

  console.log('[ProxyPilot] Switching and taking over browser proxy with profile:', target.name, target.profileType);
  updateActionBadge(target);

  if (target.profileType === 'DirectProfile') {
    setChromeProxy({ mode: 'direct' }, 'Direct Mode');
  } else if (target.profileType === 'SystemProfile') {
    setChromeProxy({ mode: 'system' }, 'System Mode');
  } else if (target.profileType === 'FixedProfile') {
    const scheme = target.fallbackProxy.scheme;
    const pHost = toPureAscii(target.fallbackProxy.host || '127.0.0.1');
    const pPort = parseInt(target.fallbackProxy.port || 7897, 10);
    const bypass = (target.bypassList || [])
      .filter(b => b.enabled)
      .map(b => toPureAscii(b.pattern))
      .filter(Boolean);
    if (bypass.length === 0) bypass.push('<local>');

    setChromeProxy({
      mode: 'fixed_servers',
      rules: {
        singleProxy: {
          scheme: scheme === 'socks5' || scheme === 'socks4' ? scheme : 'http',
          host: pHost,
          port: pPort
        },
        bypassList: bypass
      }
    }, 'Fixed Proxy (' + pHost + ':' + pPort + ')');
  } else if (target.profileType === 'SwitchProfile' || target.profileType === 'PacProfile') {
    // Generate 100% pure ASCII PAC Script
    const rawPac = buildPacScriptForProfile(target, allProfiles);
    const pureAsciiPac = toPureAscii(rawPac);

    setChromeProxy({
      mode: 'pac_script',
      pacScript: {
        data: pureAsciiPac
      }
    }, 'PAC Script Mode (' + target.profileType + ')');
  }
}

// Lifecycle listeners
chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(['profiles', 'activeProfileId']);
  if (!existing.profiles || !Array.isArray(existing.profiles) || existing.profiles.length === 0) {
    await chrome.storage.local.set({ 
      profiles: DEFAULT_PROFILES,
      activeProfileId: currentActiveProfileId
    });
  }
  applyProxySettings(existing.activeProfileId || currentActiveProfileId);
});

// Proxy Credentials Auto-Authentication (MV3 webRequestAuthProvider)
if (chrome.webRequest && chrome.webRequest.onAuthRequired) {
  chrome.webRequest.onAuthRequired.addListener(
    (details, callback) => {
      chrome.storage.local.get(['profiles', 'activeProfileId'], (res) => {
        const allProfiles = res.profiles || DEFAULT_PROFILES;
        for (let i = 0; i < allProfiles.length; i++) {
          const prof = allProfiles[i];
          if (prof.profileType === 'FixedProfile' && prof.fallbackProxy && prof.fallbackProxy.auth) {
            const u = prof.fallbackProxy.auth.username;
            const p = prof.fallbackProxy.auth.password;
            if (u && p) {
              return callback({ authCredentials: { username: u, password: p } });
            }
          }
        }
        callback({});
      });
    },
    { urls: ['<all_urls>'] },
    ['asyncBlocking']
  );
}

// In-Memory Request Logging Ring Buffer (Max 200 items for Network Debug Panel)
const MAX_REQUEST_LOGS = 200;
const requestLogs = [];

if (chrome.webRequest && chrome.webRequest.onBeforeRequest) {
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      try {
        const u = new URL(details.url);
        requestLogs.unshift({
          id: 'req_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
          timestamp: Date.now(),
          url: details.url,
          method: details.method || 'GET',
          type: details.type || 'other',
          host: u.hostname,
          port: u.port || (u.protocol === 'https:' ? '443' : '80'),
          scheme: u.protocol.replace(':', ''),
          tabId: details.tabId
        });
        if (requestLogs.length > MAX_REQUEST_LOGS) requestLogs.pop();
      } catch (e) {}
    },
    { urls: ['<all_urls>'] }
  );
}

// Hotkey Keyboard Shortcut Listener (chrome.commands)
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener(async (command) => {
    if (command === 'cycle-profile') {
      const stored = await chrome.storage.local.get(['profiles', 'activeProfileId']);
      const all = stored.profiles || DEFAULT_PROFILES;
      const currentId = stored.activeProfileId || currentActiveProfileId;
      const currentIdx = all.findIndex(p => p.id === currentId);
      const nextIdx = (currentIdx + 1) % all.length;
      const nextProfile = all[nextIdx];
      if (nextProfile) {
        await applyProxySettings(nextProfile.id);
        if (chrome.action && chrome.action.setBadgeText) {
          chrome.action.setBadgeText({ text: nextProfile.name.slice(0, 3) });
          chrome.action.setBadgeBackgroundColor({ color: nextProfile.color || '#2563eb' });
        }
      }
    } else if (command === 'toggle-direct-proxy') {
      const stored = await chrome.storage.local.get(['profiles', 'activeProfileId']);
      const currentId = stored.activeProfileId || currentActiveProfileId;
      const targetId = currentId === 'auto_switch' ? 'proxy_clash' : (currentId === 'direct' ? 'auto_switch' : 'direct');
      await applyProxySettings(targetId);
      if (chrome.action && chrome.action.setBadgeText) {
        chrome.action.setBadgeText({ text: targetId.slice(0, 3) });
      }
    }
  });
}

// Auto-Learn Failure Monitor (Captures connection reset / timed out for Smart Routing)
const autoLearnFailures = [];
if (chrome.webRequest && chrome.webRequest.onErrorOccurred) {
  chrome.webRequest.onErrorOccurred.addListener((details) => {
    try {
      const u = new URL(details.url);
      const h = u.hostname;
      if (h && !h.endsWith('.gov.cn') && !h.endsWith('.edu.cn') && !autoLearnFailures.some(f => f.host === h)) {
        autoLearnFailures.unshift({
          id: 'fail_' + Date.now(),
          host: h,
          url: details.url,
          error: details.error,
          timestamp: Date.now()
        });
        if (autoLearnFailures.length > 50) autoLearnFailures.pop();
      }
    } catch (e) {}
  }, { urls: ['<all_urls>'] });
}

// Tab Overrides Dictionary (tabId -> { profileId, expireAt })
const tabOverrides = {};

// Messages from popup or options
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'GET_STATE') {
    chrome.storage.local.get(['profiles', 'activeProfileId'], (res) => {
      const validProfiles = (res && Array.isArray(res.profiles) && res.profiles.length > 0) 
        ? res.profiles 
        : DEFAULT_PROFILES;
      sendResponse({
        profiles: validProfiles,
        activeProfileId: (res && res.activeProfileId) || currentActiveProfileId,
        tabOverrides: tabOverrides
      });
    });
    return true;
  }
  if (request.type === 'GET_PROXY_CONTROL_STATUS') {
    if (chrome.proxy && chrome.proxy.settings && chrome.proxy.settings.get) {
      chrome.proxy.settings.get({ incognito: false }, (details) => {
        const loc = (details && details.levelOfControl) || 'unknown';
        let warn = '';
        if (loc === 'controlled_by_other_extensions') {
          warn = '检测到其他代理插件正在占用浏览器代理控制权，请在 chrome://extensions 中关闭其他代理扩展。';
        } else if (loc === 'not_controllable') {
          warn = '浏览器代理被系统或企业组策略锁定。';
        }
        sendResponse({
          levelOfControl: loc,
          isControlledByThisExtension: loc === 'controlled_by_this_extension',
          activeProfileId: currentActiveProfileId,
          warningMessage: warn
        });
      });
    } else {
      sendResponse(lastControlStatus);
    }
    return true;
  }
  if (request.type === 'SWITCH_PROFILE') {
    applyProxySettings(request.profileId).then(() => {
      sendResponse({ success: true, activeProfileId: request.profileId });
    });
    return true;
  }
  if (request.type === 'OVERRIDE_TAB_PROFILE') {
    if (request.tabId) {
      if (request.profileId) {
        tabOverrides[request.tabId] = { profileId: request.profileId, expireAt: request.expireAt || 0 };
      } else {
        delete tabOverrides[request.tabId];
      }
    }
    sendResponse({ success: true, tabOverrides });
    return true;
  }
  if (request.type === 'GET_REQUEST_LOGS') {
    sendResponse({ logs: requestLogs });
    return true;
  }
  if (request.type === 'CLEAR_REQUEST_LOGS') {
    requestLogs.length = 0;
    sendResponse({ success: true });
    return true;
  }
  if (request.type === 'GET_AUTO_LEARN_FAILURES') {
    sendResponse({ failures: autoLearnFailures });
    return true;
  }
  if (request.type === 'BATCH_SET_PORT') {
    chrome.storage.local.get(['profiles', 'activeProfileId'], (res) => {
      const all = res.profiles || DEFAULT_PROFILES;
      const port = parseInt(request.port || 7897, 10);
      for (let i = 0; i < all.length; i++) {
        if (all[i].profileType === 'FixedProfile' && all[i].fallbackProxy) {
          all[i].fallbackProxy.port = port;
        }
      }
      chrome.storage.local.set({ profiles: all }, async () => {
        await applyProxySettings(res.activeProfileId || currentActiveProfileId);
        sendResponse({ success: true, profiles: all });
      });
    });
    return true;
  }
  if (request.type === 'SAVE_STATE') {
    chrome.storage.local.set({
      profiles: request.profiles,
      activeProfileId: request.activeProfileId || currentActiveProfileId
    }, async () => {
      if (request.apply) {
        await applyProxySettings(request.activeProfileId || currentActiveProfileId);
      }
      sendResponse({ success: true });
    });
    return true;
  }
});
