# ProxyPilot 浏览器代理拓展插件 (Chrome / Edge / Kiwi / Firefox)

欢迎使用 ProxyPilot 扩展插件！完全基于 Chromium 最新 Manifest V3 规范打造，默认采用 **7897** 代理端口。

---

## 📱 手机端 (Kiwi Browser / Edge Android) 极速安装步骤:

安卓端推荐使用 **Kiwi Browser**（原生完美支持 Chrome MV3 扩展）：

1. 在安卓手机打开 **Kiwi Browser**。
2. 点击右上角菜单按钮 **`⋮`** -> 选择 **「扩展程序」(Extensions)**。
3. 勾选右上角 **「开发者模式」(Developer Mode)** 开关。
4. 点击左上角的 **`+ (from .zip / .crx / .user.js)`** 按钮。
5. 在手机文件选择器中，直接选择刚刚下载的 **`ProxyPilot-Chrome-Extension-v1.0.6.zip`**（Kiwi 原生支持直接安装 ZIP，**无需解压**！）。
6. 安装完成！点击 Kiwi 菜单栏最底部的 ProxyPilot 即可在手机上像电脑一样一键切换分流和管理规则！

---

## 💻 电脑端 (Chrome / Edge / Brave / 360) 安装步骤:

1. **解压此 ZIP 压缩包** 到本地文件夹（例如 `D:\ProxyPilot-Extension`）。
2. 浏览器地址栏输入：
   - 谷歌 Chrome 浏览器：`chrome://extensions`
   - 微软 Edge 浏览器：`edge://extensions`
3. 开启页面右上角的 **"开发者模式" (Developer Mode)**。
4. 点击左上角的 **"加载已解压的扩展程序" (Load unpacked)**。
5. 选择解压出的包含 `manifest.json` 的文件夹即可完成安装！

---

## ⚙️ 默认端口配置说明:
- 默认代理端口：**127.0.0.1:7897** (对应 Clash / Mihomo / Sing-box / Clash Verge 现代混合端口)。
- 规则匹配优先级自上而下，支持域名通配符、正则与 GFWList 在线规则列表。

祝您使用愉快！
