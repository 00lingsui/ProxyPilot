// ProxyPilot - Background Service Worker (Manifest V3)
// Strictly ASCII-compliant proxy manager with Auto-Auth, Tab Override, and Smart Learn.
const DEFAULT_PROFILES = [
  {
    "id": "direct",
    "name": "直接连接 (Direct)",
    "profileType": "DirectProfile",
    "color": "#64748b"
  },
  {
    "id": "system",
    "name": "系统代理 (System)",
    "profileType": "SystemProfile",
    "color": "#0284c7"
  },
  {
    "id": "proxy_clash",
    "name": "Proxy (SOCKS5 7897)",
    "profileType": "FixedProfile",
    "color": "#10b981",
    "useSingleProxy": true,
    "fallbackProxy": {
      "scheme": "socks5",
      "host": "127.0.0.1",
      "port": 7897
    },
    "bypassList": [
      {
        "id": "b1",
        "pattern": "127.0.0.1",
        "enabled": true
      },
      {
        "id": "b2",
        "pattern": "[::1]",
        "enabled": true
      },
      {
        "id": "b3",
        "pattern": "localhost",
        "enabled": true
      },
      {
        "id": "b4",
        "pattern": "192.168.*",
        "enabled": true
      },
      {
        "id": "b5",
        "pattern": "10.*",
        "enabled": true
      },
      {
        "id": "b6",
        "pattern": "<local>",
        "enabled": true
      }
    ]
  },
  {
    "id": "proxy_http",
    "name": "HTTP 代理 (7897)",
    "profileType": "FixedProfile",
    "color": "#8b5cf6",
    "useSingleProxy": true,
    "fallbackProxy": {
      "scheme": "http",
      "host": "127.0.0.1",
      "port": 7897
    },
    "bypassList": [
      {
        "id": "b1",
        "pattern": "127.0.0.1",
        "enabled": true
      },
      {
        "id": "b2",
        "pattern": "localhost",
        "enabled": true
      },
      {
        "id": "b3",
        "pattern": "<local>",
        "enabled": true
      }
    ]
  },
  {
    "id": "auto_switch",
    "name": "自动切换 (Auto Switch)",
    "profileType": "SwitchProfile",
    "color": "#f59e0b",
    "defaultProfileId": "direct",
    "rules": [
      {
        "id": "r1",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.google.com",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "Google 国际服务"
      },
      {
        "id": "r2",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.github.com",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "GitHub 开发加速"
      },
      {
        "id": "r3",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.youtube.com",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "YouTube 媒体"
      },
      {
        "id": "r4",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.wikipedia.org",
        "profileId": "proxy_clash",
        "enabled": true,
        "note": "维基百科"
      },
      {
        "id": "r5",
        "conditionType": "HostWildcardCondition",
        "pattern": "*.internal.corp",
        "profileId": "direct",
        "enabled": true,
        "note": "公司内部服务直连"
      },
      {
        "id": "r6",
        "conditionType": "UrlRegexCondition",
        "pattern": "^https?://192\\.168\\.\\d+\\.\\d+",
        "profileId": "direct",
        "enabled": true,
        "note": "局域网网段直接访问"
      }
    ],
    "ruleListConfig": {
      "enabled": true,
      "url": "https://raw.githubusercontent.com/gfwlist/gfwlist/master/gfwlist.txt",
      "format": "AutoProxy",
      "profileId": "proxy_clash",
      "defaultProfileId": "direct",
      "rulesText": "! Sample AutoProxy / GFWList segment\n||twitter.com\n||x.com\n||facebook.com\n||instagram.com\n||reddit.com\n||medium.com\n||notion.so\n||openai.com\n@@||baidu.com\n@@||taobao.com\n@@||bilibili.com",
      "lastUpdated": "2026-10-31 08:00:00"
    }
  },
  {
    "id": "pac_custom",
    "name": "PAC 智能脚本 (PAC Script)",
    "profileType": "PacProfile",
    "color": "#ec4899",
    "pacUrl": "http://127.0.0.1:7897/proxy.pac",
    "pacScript": "function FindProxyForURL(url, host) {\n  // Local direct connection\n  if (isPlainHostName(host) ||\n      shExpMatch(host, \"*.local\") ||\n      isInNet(dnsResolve(host), \"10.0.0.0\", \"255.0.0.0\") ||\n      isInNet(dnsResolve(host), \"192.168.0.0\", \"255.255.0.0\")) {\n    return \"DIRECT\";\n  }\n\n  // Development domains\n  if (shExpMatch(host, \"*.dev.internal\")) {\n    return \"PROXY 127.0.0.1:7897; DIRECT\";\n  }\n\n  // Smart proxy routing\n  if (shExpMatch(host, \"*.google.com\") || shExpMatch(host, \"*.github.com\")) {\n    return \"SOCKS5 127.0.0.1:7897; SOCKS 127.0.0.1:7897; DIRECT\";\n  }\n\n  return \"DIRECT\";\n}"
  }
];
let currentActiveProfileId = "auto_switch";

function toPureAscii(str) {
  if (typeof str !== 'string') return '';
  return str.replace(/[^\x00-\x7F]/g, '');
}

function formatPacStatement(prof) {
  if (!prof) return 'DIRECT';
  if (prof.profileType === 'DirectProfile') return 'DIRECT';
  if (prof.profileType === 'SystemProfile') return 'SYSTEM';
  if (prof.profileType === 'FixedProfile' && prof.fallbackProxy) {
    const p = prof.fallbackProxy;
    const host = toPureAscii(p.host || '127.0.0.1');
    const port = p.port || 7897;
    const scheme = (p.scheme || 'socks5').toLowerCase();
    if (scheme === 'socks5') return 'SOCKS5 ' + host + ':' + port + '; SOCKS ' + host + ':' + port + '; DIRECT';
    if (scheme === 'socks4') return 'SOCKS ' + host + ':' + port + '; DIRECT';
    if (scheme === 'https') return 'HTTPS ' + host + ':' + port + '; DIRECT';
    return 'PROXY ' + host + ':' + port + '; DIRECT';
  }
  return 'DIRECT';
}

function buildPacScriptForProfile(target, allProfiles) {
  if (target.profileType === 'PacProfile' && target.pacScript) {
    return toPureAscii(target.pacScript);
  }
  if (target.profileType === 'DirectProfile') {
    return '// ProxyPilot PAC Script - Direct\nfunction FindProxyForURL(url, host) { return "DIRECT"; }';
  }
  if (target.profileType === 'SystemProfile') {
    return '// ProxyPilot PAC Script - System\nfunction FindProxyForURL(url, host) { return "SYSTEM"; }';
  }
  if (target.profileType === 'FixedProfile') {
    const ret = formatPacStatement(target);
    return '// ProxyPilot PAC Script - Fixed Proxy\nfunction FindProxyForURL(url, host) {\n  return "' + ret + '";\n}';
  }
  if (target.profileType === 'SwitchProfile') {
    const sw = target;
    const defProf = allProfiles.find(p => p.id === sw.defaultProfileId) || allProfiles.find(p => p.id === 'direct');
    const defaultRet = formatPacStatement(defProf);
    const ruleLines = [];
    const rules = sw.rules || [];
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i];
      if (!r.enabled) continue;
      const targetProf = allProfiles.find(p => p.id === r.profileId);
      const targetRet = formatPacStatement(targetProf);
      const cleanPat = toPureAscii(r.pattern);
      if (r.conditionType === 'HostWildcardCondition') {
        ruleLines.push('  if (shExpMatch(host, "' + cleanPat + '")) return "' + targetRet + '";');
      } else if (r.conditionType === 'UrlWildcardCondition') {
        ruleLines.push('  if (shExpMatch(url, "' + cleanPat + '")) return "' + targetRet + '";');
      } else if (r.conditionType === 'HostRegexCondition') {
        ruleLines.push('  if (/' + cleanPat + '/i.test(host)) return "' + targetRet + '";');
      } else if (r.conditionType === 'UrlRegexCondition') {
        ruleLines.push('  if (/' + cleanPat + '/i.test(url)) return "' + targetRet + '";');
      } else if (r.conditionType === 'KeywordCondition') {
        ruleLines.push('  if (url.indexOf("' + cleanPat + '") !== -1 || host.indexOf("' + cleanPat + '") !== -1) return "' + targetRet + '";');
      } else if (r.conditionType === 'IpCidrCondition') {
        ruleLines.push('  if (isInNet(host, "' + cleanPat + '", "255.255.255.0")) return "' + targetRet + '";');
      } else if (r.conditionType === 'PortCondition') {
        ruleLines.push('  if (url.indexOf(":' + cleanPat + '") !== -1) return "' + targetRet + '";');
      }
    }
    return '// ProxyPilot PAC Script - Switch Rules\nfunction FindProxyForURL(url, host) {\n' +
      (ruleLines.length ? ruleLines.join('\n') + '\n' : '') +
      '  return "' + defaultRet + '";\n}';
  }
  return 'function FindProxyForURL(url, host) { return "DIRECT"; }';
}

async function applyProxySettings(profileId) {
  if (!chrome.proxy || !chrome.proxy.settings) return;
  const storage = await chrome.storage.local.get(['profiles', 'activeProfileId']);
  const profiles = storage.profiles || DEFAULT_PROFILES;
  const activeId = profileId || storage.activeProfileId || 'auto_switch';
  const target = profiles.find(p => p.id === activeId) || profiles[0];
  currentActiveProfileId = target.id;

  if (target.profileType === 'DirectProfile') {
    chrome.proxy.settings.set({ value: { mode: 'direct' }, scope: 'regular' });
    updateActionIcon(target);
    return;
  }
  if (target.profileType === 'SystemProfile') {
    chrome.proxy.settings.set({ value: { mode: 'system' }, scope: 'regular' });
    updateActionIcon(target);
    return;
  }

  const pacScript = buildPacScriptForProfile(target, profiles);
  chrome.proxy.settings.set({
    value: {
      mode: 'pac_script',
      pacScript: { data: pacScript, mandatory: true }
    },
    scope: 'regular'
  }, () => {
    updateActionIcon(target);
  });
}

function updateActionIcon(profile) {
  if (!chrome.action) return;
  const text = profile.id === 'direct' ? '直连' : (profile.id === 'system' ? '系统' : 'PAC');
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color: profile.color || '#2563eb' });
}

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get('profiles');
  if (!existing.profiles) {
    await chrome.storage.local.set({ profiles: DEFAULT_PROFILES, activeProfileId: 'auto_switch' });
  }
  applyProxySettings('auto_switch');
});

chrome.runtime.onStartup.addListener(() => {
  applyProxySettings();
});

// Proxy 407 Auto-Auth
if (chrome.webRequest && chrome.webRequest.onAuthRequired) {
  chrome.webRequest.onAuthRequired.addListener(
    (details) => {
      if (details.isProxy) {
        return { authCredentials: { username: "proxy_user", password: "" } };
      }
    },
    { urls: ["<all_urls>"] },
    ["blocking"]
  );
}

// Shortcuts
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener(async (command) => {
    const storage = await chrome.storage.local.get(['profiles', 'activeProfileId']);
    const profiles = storage.profiles || DEFAULT_PROFILES;
    let nextId = 'direct';
    if (command === 'cycle-profile') {
      const idx = profiles.findIndex(p => p.id === storage.activeProfileId);
      const nextIdx = (idx + 1) % profiles.length;
      nextId = profiles[nextIdx].id;
    } else if (command === 'toggle-direct-proxy') {
      nextId = storage.activeProfileId === 'direct' ? 'auto_switch' : 'direct';
    }
    await chrome.storage.local.set({ activeProfileId: nextId });
    applyProxySettings(nextId);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SWITCH_PROFILE') {
    chrome.storage.local.set({ activeProfileId: msg.profileId }, () => {
      applyProxySettings(msg.profileId);
      sendResponse({ success: true });
    });
    return true;
  }
  if (msg.type === 'GET_STATE') {
    chrome.storage.local.get(['profiles', 'activeProfileId'], (res) => {
      sendResponse({ profiles: res.profiles || DEFAULT_PROFILES, activeProfileId: res.activeProfileId || currentActiveProfileId });
    });
    return true;
  }
});
