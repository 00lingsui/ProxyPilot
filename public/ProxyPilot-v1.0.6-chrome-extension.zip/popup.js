
chrome.runtime.sendMessage({ type: 'GET_STATE' }, (res) => {
  if (!res) return;
  const listEl = document.getElementById('profile-list');
  listEl.innerHTML = '';
  res.profiles.forEach(p => {
    const item = document.createElement('div');
    item.className = 'item' + (p.id === res.activeProfileId ? ' active' : '');
    item.innerHTML = '<div class="item-name"><span class="item-dot" style="background:' + (p.color || '#94a3b8') + '"></span>' + p.name + '</div>' + (p.id === res.activeProfileId ? '<span class="active-badge">✓ 生效中</span>' : '');
    item.onclick = () => {
      chrome.runtime.sendMessage({ type: 'SWITCH_PROFILE', profileId: p.id }, () => window.close());
    };
    listEl.appendChild(item);
  });
});
document.getElementById('btn-opts').onclick = () => {
  chrome.runtime.openOptionsPage ? chrome.runtime.openOptionsPage() : window.open('options.html');
};
document.getElementById('btn-tab-proxy').onclick = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0]) {
      alert('已为当前标签页临时开启代理 (10分钟)');
      window.close();
    }
  });
};
