# ProxyPilot v1.0.6 (Chrome / Edge / Kiwi Extension)

ProxyPilot 是轻量级、零广告且功能极其强大的 Chromium 现代分流代理管理套件（完美兼容 Manifest V3 标准）。

## 🚀 v1.0.6 杀手级更新亮点
1. **流量与请求抓包诊断面板 (Request Inspector)**：实时捕获浏览器发出的网络请求，展示请求 URL、命中的分流条件、最终代理目标与 HTTP 状态码，并支持在日志行中**一键添加规则**。
2. **远程 GFWList 智能转 PAC 分流器 (CloudSync GFWList -> PAC)**：一键同步远程 GFWList 规则库，极速转换为纯 ASCII 兼容、$O(1)$ 哈希匹配的紧凑 PAC 分流脚本，随时存储到本地配置。
3. **代理无感认证 (Proxy 407 Auto-Fill)**：利用 Chrome MV3 `webRequestAuthProvider` 原生捕获代理发起的 407 认证请求，静默填充凭证，彻底告别浏览器原生丑陋弹窗。
4. **扩展高级分流条件**：支持 IP CIDR 掩码网段匹配 (`isInNet`)、非标准端口匹配 (`:8443`)、URL 关键词匹配 (`KeywordCondition`) 与资源类型分流。
5. **快捷键系统与标签临时接管**：支持 `Alt+Shift+X` 循环切换情景模式、`Alt+Shift+P` 一键切换直连与自动分流，支持为单个 Tab 开启 10 分钟临时代理。

## 💻 电脑端安装方法 (Chrome / Edge / Brave / 360)
1. 解压此 ZIP 压缩包到本地目录。
2. 浏览器打开 `chrome://extensions` (Edge 打开 `edge://extensions`)。
3. 开启右上角的 **「开发者模式」**。
4. 点击 **「加载已解压的扩展程序」**，选择解压出的文件夹即可。

## 📱 手机端安装方法 (Kiwi Browser / Edge Android)
1. 在手机上安装并打开 **Kiwi Browser**。
2. 进入右上角菜单 -> 「扩展程序」 -> 开启「开发者模式」。
3. 点击 **「+ (from .zip / .crx / .user.js)」** 按钮，直接选择此 ZIP 文件即可安装！
